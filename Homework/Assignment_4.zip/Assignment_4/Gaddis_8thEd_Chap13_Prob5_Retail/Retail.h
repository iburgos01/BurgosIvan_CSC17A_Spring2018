/* 
 * File:   Retail.h
 * Author: Ivan Burgos
 * Created on April 2th, 2018, 6:53 PM
 * Purpose: Storing Retail items information
 */

#include <iostream>
using namespace std;

#ifndef RETAIL_H
#define RETAIL_H

class RtlItm{
   private:
     int size;
     string *descrp;
     int *units;
     float *price;
   public:
       RtlItm(int);
       ~RtlItm();
       setInfo(string,int,float,int); //Sets info to variables
       string getDecrp(int)const;  //Returns description of item
       int getUnit (int)const;      //Returns number of items of units
       float getPrc (int)const;     //Returns price of item
};


#endif /* RETAIL_H */

