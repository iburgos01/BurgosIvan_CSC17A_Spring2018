/* 
 * File:   Retail.cpp
 * Author: Ivan Burgos
 * Created on April 2th, 2018, 6:53 PM
 * Purpose: Storing Retail items information
 */

#include"Retail.h"
using namespace std;

RtlItm::RtlItm(int n){
    size=n;
    descrp=new string[size];
    units=new int[size];
    price=new float[size];
}

RtlItm::~RtlItm(){
    delete []descrp;
    delete []units;
    delete []price;
}

RtlItm::setInfo(string d,int n, float p,int index)
{
    if(index>=0&&index<3){
        descrp[index]=d;
        units[index]=n;
        price[index]=p;
    }
    else{
        descrp[0]=d;
        units[0]=n;
        price[0]=p;
    }
}

string RtlItm::getDecrp(int index) const{
    if(index>=0&&index<3)return descrp[index];
    else return descrp[0];
}
        
int RtlItm::getUnit(int index) const{
    if(index>=0&&index<3)return units[index];
    else return units[0];
}

float RtlItm::getPrc(int index) const{
    if(index>=0&&index<3)return price[index];
    else return price[0];
}