/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 2th, 2018, 6:53 PM
 * Purpose: Storing Retail items information
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Retail.h" //Retail class 
//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int size=3;
    RtlItm info(size); //Variable related to class
    string de;   //Description of item
    int num;     //Number of units
    float price; //Price of item
    int count=1;
    
    //Initialize Variables
    for(int i=0;i<size;i++){
    cout<<"Please enter product description"<<endl;
    cin<<de;
    cout<<"Enter number of units"<<endl;
    cin>>num;
    cout<<"Enter price of item"<<endl;
    cin>>price;
    info.setInfo(de,num,price,i);//Sets info to class
    }
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<setw(20)<<"Description"<<setw(14)<<"Units on Hand"<<setw(8)<<"Price"<<endl;
    for(int i=0;i<size;i++){
    cout<<"Item #"<<count<<setw(10)<<info.getDecrp(i)<<setw(10)
            <<info.getUnit(i)<<setw(15)<<info.getPrc(i)<<endl;
    count++;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

