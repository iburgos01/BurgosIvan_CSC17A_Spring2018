/* 
 * File:   Date.h
 * Author: Ivan Burgos
 * Created on April 3rd, 2018, 12:12 PM
 * Purpose: Storing date
 */

using namespace std;

#ifndef DATE_H
#define DATE_H

class Date{
    private:
        int day,
            month,
            year;
        string cMth;
    public:
        void setDate(int d,int m,int y){day=d;month=m;year=y;};
        int getMth()const{return month;}
        int getDay()const{return day;}
        int getYear()const{return year;}
        string getCMth()const;
};

#endif /* DATE_H */

