/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 3rd, 2018, 12:12 PM
 * Purpose: Storing Date
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Date.h" //Date class
//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    Date info; //Variable related to class
    int m,d,y; //Month, Day, and Year
    string mn;
    //Initialize Variables
   
    //Input Data/Variables
    do{
        cout<<"Enter month"<<endl;
        cin>>m;
    }while(m<1||m>12);
    do{
        cout<<"Enter day"<<endl;
        cin>>d;
    }while(d<1||d>31);
    cout<<"Enter year"<<endl;
    cin>>y;
    info.setDate(d,m,y);
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<info.getMth()<<"/"<<info.getDay()<<"/"<<info.getYear()<<endl;
    cout<<info.getCMth()<<" "<<info.getDay()<<","<<info.getYear()<<endl;
    cout<<info.getDay()<<" "<<info.getCMth()<<" "<<info.getYear()<<endl;
    //Exit the program
    return 0;
}

