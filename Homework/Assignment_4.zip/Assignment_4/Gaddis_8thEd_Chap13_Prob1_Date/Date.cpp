/* 
 * File:   Date.cpp
 * Author: Ivan Burgos
 * Created on April 3rd, 2018, 12:12 PM
 * Purpose: Storing date
 */

#include <iostream>
#include "Date.h"
using namespace std;

string Date::getCMth()const{
    string mn;
    switch(month){
        case 1:mn="January";break;
        case 2:mn="February";break;
        case 3:mn="March";break;
        case 4:mn="April";break;
        case 5:mn="May";break;
        case 6:mn="June";break;
        case 7:mn="July";break;
        case 8:mn="August";break;
        case 9:mn="September";break;
        case 10:mn="October";break;
        case 11:mn="November";break;
        case 12:mn="December";break;
    }
    return mn;
}