/* 
 * File:   Pptlin.cpp
 * Author: Ivan Burgos
 * Created on April 3rd, 2018, 8:07 PM
 * Purpose: Calculating birth and death rates
 */

#include "Ppltin.h"
using namespace std;


float Ppltin::getBR()const{
    float a; 
    a=nbirth/popul;
    return a;
}  
float Ppltin::getDR()const{
     float a;
     a=ndeath/popul;
     return a;
 } 