/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 3rd, 2018, 8:07 PM
 * Purpose: Calculating Birth and death rates
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Ppltin.h" //Population class 

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    Ppltin info; //Variable related to class
    int b,d,p; //Births, Deaths, and Population
    
    //Initialize Variables
    do{
    cout<<"Enter the number of births"<<endl;
    cin>>b;
    }while(b<1);
    do{
    cout<<"Enter the number of deaths"<<endl;
    cin>>d;
    }while(d<1);    
    cout<<"Enter the population"<<endl;
    cin>>p;
    
    //Input Data/Variables
    info.setBrth(b);
    info.setDeth(d);
    info.setPop(p);
    
    //Process or map the inputs to the outputs
    cout<<fixed<<showpoint<<setprecision(4);
    cout<<"Birth rate: "<<info.getBR()<<endl;
    cout<<"Death rate: "<<info.getDR()<<endl;
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

