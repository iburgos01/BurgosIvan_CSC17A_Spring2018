/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 3rd, 2017, 8:07 PM
 * Purpose: Calculating Birth and death rates
 */

#ifndef PPLTIN_H
#define PPLTIN_H

class Ppltin{
private:
    float nbirth;  //Number of births at the time
    float ndeath;  //Number of deaths at the time
    float popul;   //Population amount 
public:
    void setBrth(int b){nbirth=b;} //Set birth value 
    void setDeth(int d){ndeath=d;} //Set death value
    void setPop(int p){popul=p;} //Set population value
    float getBR() const; //Get the birth rate 
    float getDR() const; //Get the death rate
};


#endif /* PPLTIN_H */

