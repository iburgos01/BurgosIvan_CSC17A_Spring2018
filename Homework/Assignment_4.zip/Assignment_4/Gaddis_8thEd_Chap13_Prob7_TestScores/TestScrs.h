/* 
 * File:   TestScrs.h
 * Author: Ivan Burgos
 * Created on April 4th, 2018, 6:01 PM
 * Purpose: Test scores
 */

#ifndef TESTSCRS_H
#define TESTSCRS_H

class TestScrs{
private:
    int size;    //Size of students in class 
    int *scores; //Pointer for students test scores
public:
    TestScrs(int);
    ~TestScrs(){delete []scores;}
    void setScores(int *,int);
    int getScores(int index){return scores[index];}
    float getAvrge();
};


#endif /* TESTSCRS_H */

