/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 4th, 2018, 6:01 PM
 * Purpose: Test scores
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "TestScrs.h"
//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int size=3;
    TestScrs info(size);
    int *grade;
    
    //Initialize Variables
    
    //Input Data/Variables
    grade=new int[size];
    //Process or map the inputs to the outputs
    cout<<"Please enter the scores of students"<<endl;
    for(int i=0;i<size;i++){
        cin>>grade[i];
        info.setScores(grade,i);
    }
    
    //Display/Output all pertinent variables
    delete []grade;
    cout<<"Average grade: "<<info.getAvrge()<<endl;
    //Exit the program
    return 0;
}

