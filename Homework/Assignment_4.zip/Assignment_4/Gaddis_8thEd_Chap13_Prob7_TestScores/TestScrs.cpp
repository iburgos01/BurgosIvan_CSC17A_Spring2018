/* 
 * File:   TestScrs.cpp
 * Author: Ivan Burgos
 * Created on April 4th, 2018, 6:01 PM
 * Purpose: Test scores
 */

#include "TestScrs.h"

using namespace std;

TestScrs::TestScrs(int n){
    size=n<0?3:n;
    scores=new int[size]; 
}

void TestScrs::setScores(int *ts,int index){
    if(index>=0&&index<size)scores[index]=ts[index];
    else scores[index]=0;
}

float TestScrs::getAvrge(){
    float average;
    for(int i=0;i<size;i++){
        average+=scores[i];
    }
    return average/size;
}