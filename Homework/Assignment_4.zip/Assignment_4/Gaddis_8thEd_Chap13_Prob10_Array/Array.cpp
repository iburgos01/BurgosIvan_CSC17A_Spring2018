/* 
 * File:   Array.cpp
 * Author: Ivan Burgos
 * Created on November 15th, 2017, 8:07 PM
 * Purpose: CPP Template
 */

#include <cstdlib>
#include "Array.h"
using namespace std;


Array::Array(int n){
    size=n<1?2:n>100?100:n;
    num=new float[size];
    num[size]={};
}

void Array::store(float d,int index){
    if(index>=0&&index<size)num[index]=d;
    else num[0]=d;
}

float Array::retrieve(int index){
    if(index>=0&&index<size)return num[index];
    else return num[0];
}

float Array::highest(){
    float hghest=0;
    for(int i=0;i<size;i++){
        if(num[i]>hghest)hghest=num[i];
    }
}

float Array::lowest(){
    float lowest=100;
    for(int i=0;i<size;i++){
        if(num[i]<lowest)lowest=num[i];
    }
}

float Array::average(){
    float aver;
    for(int i=0;i<size;i++){
        aver+=num[i];
    }
    return aver/size;
}