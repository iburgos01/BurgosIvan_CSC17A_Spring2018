/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 15th, 2017, 8:07 PM
 * Purpose: CPP Template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Array.h"
//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int size=10;
    Array array(size);
    bool loop=true;
    int i;
    float num;
    char choice;
    //Initialize Variables
    do{
        cout<<"Enter location to be stored"<<endl;
        cin>>i;
        cout<<"Enter number to be stored"<<endl;
        cin>>num;
        array.store(num,i);
        cout<<"Would you like to continue(Y/N)"<<endl;
        cin>>choice;
        if(choice=='N'||choice=='n')loop=false;
    }while(loop);
    do{
        cout<<"Enter location to retrieve"<<endl;
        cin>>i;
        cout<<array.retrieve(i)<<endl;
        cout<<"Would you like to continue(Y/N)"<<endl;
        cin>>choice;
        if(choice=='N'||choice=='n')loop=false;
    }while(loop);
    //Input Data/Variables
    cout<<"Highest: "<<array.highest()<<endl;
    cout<<"Lowest:  "<<array.lowest()<<endl;
    cout<<"Average: "<<array.average()<<endl;
    //Process or map the inputs to the outputs
   
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

