/* 
 * File:   Array.h
 * Author: Ivan Burgos
 * Created on November 15th, 2017, 8:07 PM
 * Purpose: CPP Template
 */


#ifndef ARRAY_H
#define ARRAY_H

class Array{
private:
    int size;
    float *num;
public:
    Array(int);
    ~Array(){delete []num;}
    void store(float,int);
    float retrieve(int);
    float highest();
    float lowest();
    float average();
}; 


#endif /* ARRAY_H */

