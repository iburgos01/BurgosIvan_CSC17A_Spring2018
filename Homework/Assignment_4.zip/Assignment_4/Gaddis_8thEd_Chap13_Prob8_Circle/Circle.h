/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 4th, 2018, 9:17 PM
 * Purpose: Getting info of circle
 */

#ifndef CIRCLE_H
#define CIRCLE_H

class Circle{
private:
    float radius;
    float pi;
public:
    Circle(){radius=0.0; pi=3.14159;} //Constructor
    void setRads(float r){radius=r;}  //Function to set radius
    float getRads(){return radius;}   //Gets the Radius value
    float getDia(){return radius*2;}  //Gets Diameter
    float getArea(){return pi*radius*radius;} //Gets the area
    float getCir(){return 2*pi*radius;}  //Get Circumference
};

#endif /* CIRCLE_H */

