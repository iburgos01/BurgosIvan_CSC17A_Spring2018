/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on April 4th, 2018, 9:17 PM
 * Purpose: Getting info of circle
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Circle.h" //Circle class
//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    Circle radius; //Variable related to class
    float r;   //Receives radius to be stored
    //Initialize Variables
    cout<<"Enter the radius"<<endl;
    cin>>r;
    //Input Data/Variables
    radius.setRads(r);  //Passes radius to be stored
    
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<"Area: "<<radius.getArea()<<endl;
    cout<<"Diameter: "<<radius.getDia()<<endl;
    cout<<"Circumference: "<<radius.getCir()<<endl;
    
    //Exit the program
    return 0;
}

