/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Weather.h
 * Author: Ivan
 *
 * Created on March 26, 2018, 5:39 AM
 */

#ifndef WEATHER_H
#define WEATHER_H

struct WthrSt{
    int totRf,//Total Rainfall
        hTemp,//High Temperature
        lTemp,//Low Temperature
        aTemp;//Average Temperature
};

#endif /* WEATHER_H */

