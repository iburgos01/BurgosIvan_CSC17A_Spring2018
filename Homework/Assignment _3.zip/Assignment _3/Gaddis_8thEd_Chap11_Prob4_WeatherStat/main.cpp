/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 24th, 2018, 8:33 PM
 * Purpose: Weather Statistics
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Weather.h"//Structure for Weather

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes
void filInfo(WthrSt);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=12;
    WthrSt data[SIZE]={};
    
    //Initialize Variables
   
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
   
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

