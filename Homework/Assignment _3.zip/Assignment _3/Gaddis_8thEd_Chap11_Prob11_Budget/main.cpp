/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 20th, 2018, 7:49 PM
 * Purpose: CPP Template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Speaker.h"
//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    Speaker spkr;
    
    //Initialize Variables
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
   
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

