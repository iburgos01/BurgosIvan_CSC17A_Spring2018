/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 22nd, 2018, 10:22 AM
 * Purpose:  Movie data 
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here
#include "MovieData.h"
//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=50;
    MveData info[SIZE];
    //Input or initialize values Here
    cout<<"Enter name of movie"<<endl;
    getline(cin,info->title);
    cout<<"Enter the director's name"<<endl;
    getline(cin,info->drtor);
    cout<<"Enter year it was released"<<endl;
    getline(cin,info->ryear);
    cout<<"Enter the run time of movie"<<endl;
    getline(cin,info->rtime);
    cout<<"Enter the movies production cost"<<endl;
    getline(cin,info->pCost);
    cout<<"Enter the movies profit or loss"<<endl;
    getline(cin,info->mRev);
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"Movie: "<<setw(26)<<info->title<<endl;
    cout<<"Director's Name: "<<info->drtor<<endl;
    cout<<"Release Year: "<<setw(7)<<info->ryear<<endl;
    cout<<"Runtime: "<<setw(16)<<info->rtime<<endl;
    cout<<"Production Cost: "<<info->pCost<<endl;
    cout<<"Movie Revenue: "<<setw(10)<<info->mRev<<endl;
    
    //Exit
    return 0;
}

