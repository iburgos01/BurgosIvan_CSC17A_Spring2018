/* 
 * File:   Scores.h
 * Author: Ivan
 *
 * Created on March 25, 2018, 1:22 PM
 */

#ifndef SCORES_H
#define SCORES_H

struct ScrScre{
    string plyrNam;
    int  plyrNum;
    int  score;
};


#endif /* SCORES_H */

