/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 25th, 2018, 11:17 PM
 * Purpose: Soccer Scores
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Scores.h"  //Structure Library for score info

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=12;    //Size of array 
    ScrScre data[SIZE]={};//Variable of Structure
    int totScr=0;         //Total Score Made
    
    //Initialize Variables
    for(int i=0;i<SIZE;i++){      //For-loop filling info
        cout<<"Enter name of player"<<endl;
        cin>>data[i].plyrNam;
        do{
        cout<<"Enter Player's Number"<<endl;
        cin>>data[i].plyrNum;
        }while(data[i].plyrNum<0);
        do{
        cout<<"Enter the score made by player"<<endl;
        cin>>data[i].score;
        }while(data[i].score<0);
        totScr+=data[i].score;   //Calculating total score
    }
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<"Player Name"<<setw(8)<<"Number"<<setw(7)<<"Score"<<endl;
    for(int i=0;i<SIZE;i++){
        cout<<data[i].plyrNam;
        cout<<setw(15)<<data[i].plyrNum;
        cout<<setw(8)<<data[i].score<<endl;
    }
    
    cout<<"Total Score "<<totScr<<endl;
    //Exit the program
    return 0;
}

