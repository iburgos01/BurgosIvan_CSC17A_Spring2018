/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 26th, 2018, 8:00 AM
 * Purpose: Corporate Sales Data
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Corporate.h" //Structure for Corporate Sales

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
void eSal(SalDta);//East Sales Function
void wSal(SalDta);//West Sales Function
void nSal(SalDta);//North Sales Function
void sSal(SalDta);//South Sales Function

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    SalDta east;
    SalDta west;
    SalDta north;
    SalDta south; 
    
    //Initialize Variables
    eSal(east);
    wSal(west);
    nSal(north);
    sSal(south);
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
   
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

void eSal(SalDta east){
    cout<<"Enter the first quarter sales"<<endl;
    do{
      cin>>east.fqSal;
    }while(east.fqSal<0);
    cout<<"Enter the Second quarter sales"<<endl;
    do{
      cin>>east.sqSal;
    }while(east.sqSal<0);
    cout<<"Enter the third quarter sales"<<endl;
    do{
      cin>>east.tqSal;
    }while(east.tqSal<0);
    cout<<"Enter the fourth quarter sales"<<endl;
    do{
      cin>>east.foqSal;
    }while(east.foqSal<0);
    east.taSal=east.fqSal+east.sqSal+east.tqSal+east.foqSal;
    east.aqSal=(east.fqSal+east.sqSal+east.tqSal+east.foqSal)/4;
    cout<<"East"<<endl;
    cout<<"First-Quarter Sales =   "<<east.fqSal<<endl;
    cout<<"Second-Quarter Sales =  "<<east.sqSal<<endl;
    cout<<"Third-Quarter Sales =   "<<east.tqSal<<endl;
    cout<<"Fourth-Quarter Sales =  "<<east.foqSal<<endl;
    cout<<"Total Annual Sales =    "<<east.taSal<<endl;
    cout<<"Average Quarter Sales = "<<east.aqSal<<endl;
    
}

void wSal(SalDta west){
    cout<<"Enter the first quarter sales"<<endl;
    do{
      cin>>west.fqSal;
    }while(west.fqSal<0);
    cout<<"Enter the Second quarter sales"<<endl;
    do{
      cin>>west.sqSal;
    }while(west.sqSal<0);
    cout<<"Enter the third quarter sales"<<endl;
    do{
      cin>>west.tqSal;
    }while(west.tqSal<0);
    cout<<"Enter the fourth quarter sales"<<endl;
    do{
      cin>>west.foqSal;
    }while(west.foqSal<0);
    west.taSal=west.fqSal+west.sqSal+west.tqSal+west.foqSal;
    west.aqSal=(west.fqSal+west.sqSal+west.tqSal+west.foqSal)/4;
    cout<<"West"<<endl;
    cout<<"First-Quarter Sales =   "<<west.fqSal<<endl;
    cout<<"Second-Quarter Sales =  "<<west.sqSal<<endl;
    cout<<"Third-Quarter Sales =   "<<west.tqSal<<endl;
    cout<<"Fourth-Quarter Sales =  "<<west.foqSal<<endl;
    cout<<"Total Annual Sales =    "<<west.taSal<<endl;
    cout<<"Average Quarter Sales = "<<west.aqSal<<endl;
    
}

void nSal(SalDta north){
    cout<<"Enter the first quarter sales"<<endl;
    do{
      cin>>north.fqSal;
    }while(north.fqSal<0);
    cout<<"Enter the Second quarter sales"<<endl;
    do{
      cin>>north.sqSal;
    }while(north.sqSal<0);
    cout<<"Enter the third quarter sales"<<endl;
    do{
      cin>>north.tqSal;
    }while(north.tqSal<0);
    cout<<"Enter the fourth quarter sales"<<endl;
    do{
      cin>>north.foqSal;
    }while(north.foqSal<0);
    north.taSal=north.fqSal+north.sqSal+north.tqSal+north.foqSal;
    north.aqSal=(north.fqSal+north.sqSal+north.tqSal+north.foqSal)/4;
    cout<<"North"<<endl;
    cout<<"First-Quarter Sales =   "<<north.fqSal<<endl;
    cout<<"Second-Quarter Sales =  "<<north.sqSal<<endl;
    cout<<"Third-Quarter Sales =   "<<north.tqSal<<endl;
    cout<<"Fourth-Quarter Sales =  "<<north.foqSal<<endl;
    cout<<"Total Annual Sales =    "<<north.taSal<<endl;
    cout<<"Average Quarter Sales = "<<north.aqSal<<endl;
    
}

void sSal(SalDta south){
    cout<<"Enter the first quarter sales"<<endl;
    do{
      cin>>south.fqSal;
    }while(south.fqSal<0);
    cout<<"Enter the Second quarter sales"<<endl;
    do{
      cin>>south.sqSal;
    }while(south.sqSal<0);
    cout<<"Enter the third quarter sales"<<endl;
    do{
      cin>>south.tqSal;
    }while(south.tqSal<0);
    cout<<"Enter the fourth quarter sales"<<endl;
    do{
      cin>>south.foqSal;
    }while(south.foqSal<0);
    south.taSal=south.fqSal+south.sqSal+south.tqSal+south.foqSal;
    south.aqSal=(south.fqSal+south.sqSal+south.tqSal+south.foqSal)/4;
    cout<<"South"<<endl;
    cout<<"First-Quarter Sales =   "<<south.fqSal<<endl;
    cout<<"Second-Quarter Sales =  "<<south.sqSal<<endl;
    cout<<"Third-Quarter Sales =   "<<south.tqSal<<endl;
    cout<<"Fourth-Quarter Sales =  "<<south.foqSal<<endl;
    cout<<"Total Annual Sales =    "<<south.taSal<<endl;
    cout<<"Average Quarter Sales = "<<south.aqSal<<endl;
    
}