/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 26th, 2018, 8:00 AM
 * Purpose: Corporate Sales Data
 */

#ifndef CORPORATE_H
#define CORPORATE_H

struct SalDta{
    int fqSal, //First-Quarter Sale
        sqSal, //Second-Quarter Sale
        tqSal, //Third-Quarter Sale
        foqSal,//Fourth-Quarter Sale 
        taSal, //Total Annual Sales 
        aqSal; //Average Quarterly Sales
};

#endif /* CORPORATE_H */

