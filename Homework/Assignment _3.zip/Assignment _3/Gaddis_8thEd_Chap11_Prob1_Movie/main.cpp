/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 22nd, 2018, 10:22 AM
 * Purpose:  Movie data 
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here
#include "MovieData.h"
//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=50;
    MveData info[SIZE];
    //Input or initialize values Here
    cout<<"Enter name of movie"<<endl;
    getline(cin,info->title);
    cout<<"Enter the director's name"<<endl;
    getline(cin,info->drtor);
    cout<<"Enter year it was released"<<endl;
    getline(cin,info->ryear);
    cout<<"Enter the run time of movie"<<endl;
    getline(cin,info->rtime);
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"Movie: "<<setw(11)<<info->title<<endl;
    cout<<"Director's Name: "<<info->drtor<<endl;
    cout<<"Release Year: "<<setw(4)<<info->ryear<<endl;
    cout<<"Runtime: "<<setw(9)<<info->rtime<<endl;
    
    //Exit
    return 0;
}

