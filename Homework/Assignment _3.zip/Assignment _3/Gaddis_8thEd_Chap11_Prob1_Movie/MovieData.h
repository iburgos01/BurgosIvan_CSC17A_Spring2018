/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 22nd, 2018, 10:22 AM
 * Purpose:  Movie data 
 */
#ifndef MOVIEDATA_H
#define MOVIEDATA_H

struct MveData{
    string title; //Title of the movie 
    string drtor; //Director of the movie
    string ryear; //Release year
    string rtime; //Run time of movie
};

#endif /* MOVIEDATA_H */

