/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 20th, 2018, 8:32 PM
 * Purpose: Checking Budget 
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries
#include "Budget.h"
//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
void askspt(MonSpt &);
void print(Budget &,MonSpt &);
//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    Budget bdgt; //Budget Set for months
    MonSpt spt;  //Amount spent during month       
    //Initialize Variables
    askspt(spt);
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    print(bdgt,spt);
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

void askspt(MonSpt &spt){
    cout<<"Enter amount spent on Housing"<<endl;
    cin>>(spt.husing);
    cout<<"Enter amount spent on Utilities"<<endl;
    cin>>(spt.utility);
    cout<<"Enter amount spent on Housing Expenses"<<endl;
    cin>>(spt.hexpn);
    cout<<"Enter amount spent on Transportation"<<endl;
    cin>>(spt.trans);
    cout<<"Enter amount spent on Food"<<endl;
    cin>>(spt.food);
    cout<<"Enter amount spent on Medical"<<endl;
    cin>>(spt.med);
    cout<<"Enter amount spent on Insurance"<<endl;
    cin>>(spt.insr);
    cout<<"Enter amount spent on Entertainment"<<endl;
    cin>>(spt.etrmt);
    cout<<"Enter amount spent on Clothing"<<endl;
    cin>>(spt.cloth);
    cout<<"Enter amount spent on Miscellaneous"<<endl;
    cin>>(spt.misc);
}

void print(Budget &bdgt,MonSpt &spt){
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Type"<<setw(21)<<"Budget"<<setw(9)<<"Spent"<<endl;
    cout<<"Housing"<<setw(18)<<(bdgt.husing)<<setw(9)<<(spt.husing);
    if((bdgt.husing)>(spt.husing))cout<<setw(6)<<"Low"<<endl;
    else if((bdgt.husing)<(spt.husing))cout<<setw(6)<<"High"<<endl;
    cout<<"Utilities"<<setw(16)<<(bdgt.utility)<<setw(9)<<(spt.utility);
    if((bdgt.utility)>(spt.utility))cout<<setw(6)<<"Low"<<endl;
    else if((bdgt.utility)<(spt.utility))cout<<setw(6)<<"High"<<endl;
    cout<<"Household Expense"<<setw(8)<<(bdgt.hexpn)<<setw(9)<<(spt.hexpn);
    if((bdgt.hexpn)>(spt.hexpn))cout<<setw(6)<<"Low"<<endl;
    else if((bdgt.hexpn)<(spt.hexpn))cout<<setw(6)<<"High"<<endl;
    cout<<"Transportation"<<setw(11)<<(bdgt.trans)<<setw(9)<<(spt.trans);
    if((bdgt.trans)>(spt.trans))cout<<setw(6)<<"Low"<<endl;
    else if((bdgt.trans)<(spt.trans))cout<<setw(6)<<"High"<<endl;
     cout<<"Food"<<setw(21)<<(bdgt.food)<<setw(9)<<(spt.food);
    if(bdgt.food>spt.food)cout<<setw(6)<<"Low"<<endl;
    else if(bdgt.food<spt.food)cout<<setw(6)<<"High"<<endl;
     cout<<"Medical"<<setw(18)<<bdgt.med<<setw(9)<<spt.med;
    if(bdgt.med>spt.med)cout<<setw(6)<<"Low"<<endl;
    else if(bdgt.med<spt.med)cout<<setw(6)<<"High"<<endl;
     cout<<"Insurance"<<setw(16)<<bdgt.insr<<setw(9)<<spt.insr;
    if(bdgt.insr>spt.insr)cout<<setw(6)<<"Low"<<endl;
    else if(bdgt.insr<spt.insr)cout<<setw(6)<<"High"<<endl;
     cout<<"Entertainment"<<setw(12)<<bdgt.etrmt<<setw(9)<<spt.etrmt;
    if(bdgt.etrmt>spt.etrmt)cout<<setw(6)<<"Low"<<endl;
    else if(bdgt.etrmt<spt.etrmt)cout<<setw(6)<<"High"<<endl;
     cout<<"Clothing"<<setw(17)<<bdgt.cloth<<setw(9)<<spt.cloth;
    if(bdgt.cloth>spt.cloth)cout<<setw(6)<<"Low"<<endl;
    else if(bdgt.cloth<spt.cloth)cout<<setw(6)<<"High"<<endl;
     cout<<"Miscellaneous"<<setw(12)<<bdgt.misc<<setw(9)<<spt.misc;
    if(bdgt.misc>spt.misc)cout<<setw(6)<<"Low"<<endl;
    else if(bdgt.misc<spt.misc)cout<<setw(6)<<"High"<<endl;
}