/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Budget.h
 * Author: Ivan
 *
 * Created on March 20, 2018, 8:31 PM
 */

#ifndef BUDGET_H
#define BUDGET_H
struct Budget{
   float husing=500.00, 
       utility=150.00, 
       hexpn=65.00, 
       trans=50.00,
       food=250.00,
       med=30.00, 
       insr=100.00, 
       etrmt=150.00, 
       cloth=75.00,
       misc=50.00;
};

struct MonSpt{
   float husing, 
       utility, 
       hexpn, 
       trans,
       food,
       med, 
       insr, 
       etrmt, 
       cloth,
       misc;
};

#endif /* BUDGET_H */

