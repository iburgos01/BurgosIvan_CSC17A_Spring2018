/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here
#include "SimpleVector.h"

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int size=50;
    SimpleVector<int> vctr(size);
    int pstin;
    //Input or initialize values Here
    cout<<"The size of the array"<<vctr.size()<<endl;
    
    cout<<"Enter a position to fetch"<<endl;
    cin>>pstin;
    
    cout<<vctr.getElementAt(pstin)<<endl;
    cout<<vctr.operator [](pstin)<<endl;
    
    //Process/Calculations Here
    
    //Output Located Here
    

    //Exit
    return 0;
}

