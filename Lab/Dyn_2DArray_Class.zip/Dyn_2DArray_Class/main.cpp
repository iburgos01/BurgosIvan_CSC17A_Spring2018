/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 27th, 2018, 10:23 AM
 * Purpose:  Dynamic 2-D Array with Class
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>   //srand, rand
#include <ctime>

#include "Array.h"   //Time
using namespace std;

//User Libraries

//Global Constants - Math, Science, Conversions, 2D Array Sizes

//Function Prototypes
void prntAry(const Array &);


//Executions Begin Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare and allocate memory for the array
    int row=10,col=20;
    Array array=Array(row,col);
    
    //Print the random 2-Digit array
    prntAry(array);
    
    //Deallocate memory
    

    return 0;
}

void prntAry(const Array &a){
    cout<<endl;
    for(int row=0;row<a.getRows();row++){
        for(int col=0;col<a.getCols();col++){
            cout<<a.getdata(row,col)<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}

