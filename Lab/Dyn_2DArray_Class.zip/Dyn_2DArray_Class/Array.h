/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 27th, 2018, 10:23 AM
 * Purpose:  Dynamic 2-D Array with Class

#ifndef ARRAY_H
#define ARRAY_H

class Array{
 */

#ifndef ARRAY_H
#define ARRAY_H

class Array{
    private:
        int rows;
        int cols;
        int **data;
    public:
        Array(int,int);
        ~Array(){delete []data;}
        int getdata(int,int)const;
        int getRows()const{return rows;}
        int getCols()const{return cols;}
};



#endif /* ARRAY_H */

