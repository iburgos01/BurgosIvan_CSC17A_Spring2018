/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on March 27th, 2018, 10:23 AM
 * Purpose:  Dynamic 2-D Array with Class
 */

#include "Array.h"
#include <cstdlib>
#include <ctime>
using namespace std;

Array::Array(int r,int c){
    rows=r<=1?2:r>1000?1000:r;
    cols=c<=1?2:c>1000?1000:c;
    
    data=new int*[rows];
    for(int row=0;row<rows;row++){
        data[row]=new int[cols];
    }
    
    //Fill with 2 digit random numbers
    for(int row=0;row<rows;row++){
        for(int col=0;col<cols;col++){
            data[row][col]=rand()%90+10;
        }
    }
    
}

int Array::getdata(int row, int col)const{
    if(row>=0&&row<rows){
        if(col>=0&&row<cols)return data[row][col];
        return data[row][0];
    }
    else return data[0][0];
}
